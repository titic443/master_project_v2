// PICT Pairwise Combinatorial Testing Module
//
// This module provides utilities for generating pairwise test combinations using:
// 1. External PICT binary (Microsoft PICT tool)
// 2. Internal pairwise algorithm (fallback when PICT unavailable)
//
// Key Features:
// - Generate PICT model files from UI manifests
// - Execute PICT binary and parse results
// - Internal pairwise generation algorithm
// - Support for factors: TEXT fields, Radio groups, Dropdowns

import 'dart:convert';
import 'dart:io';

import 'utils.dart' as utils;

// ============================================================================
// GeneratorPict Class
// ============================================================================

class GeneratorPict {
  final String pictBin;
  const GeneratorPict({this.pictBin = './pict'});

  // ==========================================================================
  // PICT Model Generation
  // ==========================================================================

  /// Generate PICT model from factors map with optional constraints
  ///
  /// Example input:
  /// ```dart
  /// {
  ///   'TEXT': ['valid', 'invalid'],
  ///   'Radio1': ['yes', 'no'],
  ///   'Dropdown': ['option1', 'option2', 'option3']
  /// }
  /// ```
  ///
  /// Output:
  /// ```
  /// TEXT: valid, invalid
  /// Radio1: yes, no
  /// Dropdown: "option1", "option2", "option3"
  ///
  /// IF [Type] = "RAID-5" THEN [Compression] = "Off";
  /// ```
  String generatePictModel(Map<String, List<String>> factors, {String? constraints}) {
    // DEBUG: Check constraints parameter (uncomment for debugging)
    // stderr.writeln('[DEBUG] generatePictModel - constraints: ${constraints == null ? "NULL" : "\"${constraints.trim()}\""}');

    final buffer = StringBuffer();
    for (final entry in factors.entries) {
      buffer.writeln('${entry.key}: ${_formatValuesForModel(entry.key, entry.value)}');
    }

    // Add constraints if provided — only pass Format B (IF/THEN) lines to PICT.
    // Format A lines (key = value  or  key.slot = value) are dataset overrides
    // consumed by generate_test_data.dart and must NOT be forwarded to PICT.
    if (constraints != null && constraints.trim().isNotEmpty) {
      final pictLines = constraints
          .split('\n')
          .map((l) => l.trim())
          .where((l) => l.isNotEmpty && !l.startsWith('#'))
          .where((l) => l.toUpperCase().contains('IF') && l.toUpperCase().contains('THEN'))
          .join('\n');
      if (pictLines.isNotEmpty) {
        buffer.writeln('');
        buffer.writeln(pictLines);
      }
    }

    return buffer.toString();
  }

  /// Generate valid-only PICT model (excludes 'invalid' from TEXT factors and 'unchecked' from required checkboxes)
  String generateValidOnlyPictModel(
    Map<String, List<String>> factors, {
    Set<String> requiredCheckboxes = const {},
    String? constraints,
  }) {
    final buffer = StringBuffer();
    for (final entry in factors.entries) {
      // Check if this is a text field factor (contains 'valid' and 'invalid')
      final isTextField = entry.value.contains('valid') && entry.value.contains('invalid');

      if (isTextField) {
        // For TEXT factors, only use 'valid' values
        final validValues = entry.value.where((v) => v != 'invalid').toList();
        if (validValues.isNotEmpty) {
          buffer.writeln('${entry.key}: ${_formatValuesForModel(entry.key, validValues)}');
        }
      } else if (requiredCheckboxes.contains(entry.key)) {
        // For required checkboxes, only use 'checked' value
        final validValues = entry.value.where((v) => v != 'unchecked').toList();
        if (validValues.isNotEmpty) {
          buffer.writeln('${entry.key}: ${_formatValuesForModel(entry.key, validValues)}');
        }
      } else {
        // For non-TEXT factors (Radio, Dropdown, DatePicker, TimePicker, optional Checkbox)
        // Exclude 'null' (cancel/skip) and past dates — valid model needs only real valid values
        final today = DateTime.now();
        final todayOnly = DateTime(today.year, today.month, today.day);
        final validValues = entry.value.where((v) {
          if (v == 'null') return false;
          // Parse dd/mm/yyyy — exclude past dates
          final parts = v.split('/');
          if (parts.length == 3) {
            final d = int.tryParse(parts[0]);
            final m = int.tryParse(parts[1]);
            final y = int.tryParse(parts[2]);
            if (d != null && m != null && y != null) {
              return !DateTime(y, m, d).isBefore(todayOnly);
            }
          }
          return true;
        }).toList();
        if (validValues.isNotEmpty) {
          buffer.writeln('${entry.key}: ${_formatValuesForModel(entry.key, validValues)}');
        }
      }
    }

    // Add constraints if provided — only pass Format B (IF/THEN) lines to PICT.
    if (constraints != null && constraints.trim().isNotEmpty) {
      final pictLines = constraints
          .split('\n')
          .map((l) => l.trim())
          .where((l) => l.isNotEmpty && !l.startsWith('#'))
          .where((l) => l.toUpperCase().contains('IF') && l.toUpperCase().contains('THEN'))
          .join('\n');
      if (pictLines.isNotEmpty) {
        buffer.writeln('');
        buffer.writeln(pictLines);
      }
    }

    return buffer.toString();
  }

  /// Format values for PICT model syntax.
  ///
  /// Detection is value-content-based (not factor-name-based):
  /// - "Bucket" factors (text fields, switches, checkboxes) use symbolic sentinel
  ///   values like 'valid'/'invalid'/'on'/'off'/'checked'/'unchecked'.
  ///   These are plain ASCII and do NOT need quoting.
  /// - All other factors (dropdowns, radios) carry actual option values which may
  ///   contain Thai characters, spaces, or special strings like "4+" that PICT
  ///   cannot parse without double-quotes. These MUST be quoted.
  String _formatValuesForModel(String factorName, List<String> values) {
    const bucketValues = {'valid', 'invalid', 'on', 'off', 'checked', 'unchecked'};
    final isBucketFactor = values.any((v) => bucketValues.contains(v));
    if (isBucketFactor) {
      return values.join(', ');
    }
    // Dropdown / radio actual option values — quote for PICT compatibility
    // (handles Thai characters, spaces, "4+", and other special strings)
    final quoted = values.map((v) {
      final escaped = v.replaceAll('"', '\\"');
      return '"$escaped"';
    }).toList();
    return quoted.join(', ');
  }

  // ==========================================================================
  // PICT Execution
  // ==========================================================================

  /// Execute PICT binary to generate pairwise combinations
  ///
  /// Parameters:
  /// - factors: Map of factor names to their possible values
  /// - constraints: Optional PICT constraints
  ///
  /// Returns: List of test case combinations as Maps
  ///
  /// Example:
  /// ```dart
  /// final combos = await executePict({
  ///   'TEXT': ['valid', 'invalid'],
  ///   'Radio1': ['yes', 'no']
  /// }, constraints: 'IF [TEXT] = "invalid" THEN [Radio1] = "no";');
  /// // Result: [{'TEXT': 'valid', 'Radio1': 'yes'}, {'TEXT': 'invalid', 'Radio1': 'no'}]
  /// ```
  Future<List<Map<String, String>>> executePict(
    Map<String, List<String>> factors, {
    String? constraints,
  }) async {
    if (factors.isEmpty) return const [];

    // Generate PICT model content with constraints
    final modelContent = generatePictModel(factors, constraints: constraints);

    // Write temp model file under .dart_tool
    final tmpDir = Directory('.dart_tool');
    if (!tmpDir.existsSync()) {
      tmpDir.createSync(recursive: true);
    }
    final modelPath = '.dart_tool/pairwise_model.tmp.txt';
    File(modelPath).writeAsStringSync(modelContent);

    // Execute PICT
    final result = await Process.run(pictBin, [modelPath]);
    if (result.exitCode != 0) {
      throw Exception('PICT exit code ${result.exitCode}: ${result.stderr}');
    }

    final output = (result.stdout is String)
        ? (result.stdout as String)
        : String.fromCharCodes((result.stdout as List<int>));

    return parsePictResult(output);
  }

  /// Parse PICT result output (tab-separated format)
  ///
  /// Example input:
  /// ```
  /// TEXT	Radio1
  /// valid	yes
  /// invalid	no
  /// ```
  ///
  /// Returns: `[{'TEXT': 'valid', 'Radio1': 'yes'}, {'TEXT': 'invalid', 'Radio1': 'no'}]`
  List<Map<String, String>> parsePictResult(String content) {
    final lines = content.trim().split(RegExp(r'\r?\n')).where((l) => l.trim().isNotEmpty).toList();
    if (lines.isEmpty) return const [];

    final header = lines.first.split('\t').map((s) => s.trim()).toList();
    final combos = <Map<String, String>>[];

    for (int i = 1; i < lines.length; i++) {
      final cols = lines[i].split('\t');
      if (cols.length != header.length) continue;

      final combination = <String, String>{};
      for (int c = 0; c < header.length; c++) {
        combination[header[c]] = cols[c].trim();
      }
      combos.add(combination);
    }

    return combos;
  }

  /// Parse PICT model file to extract factor names and their values
  ///
  /// Example input:
  /// ```
  /// customer_01_firstname_textfield: valid, invalid
  /// age_radio_group: age_10_20_radio, age_30_40_radio
  /// customer_07_title_dropdown: "Mr.", "Mrs.", "Ms."
  /// ```
  ///
  /// Returns: Map of factor names to their possible values
  Map<String, List<String>> parsePictModel(String content) {
    final factors = <String, List<String>>{};
    final lines = content.trim().split(RegExp(r'\r?\n')).where((l) => l.trim().isNotEmpty).toList();

    for (final line in lines) {
      // Skip comments and empty lines
      if (line.trim().isEmpty || line.trim().startsWith('#')) continue;

      // Parse factor line: "FactorName: value1, value2, value3"
      final colonIdx = line.indexOf(':');
      if (colonIdx == -1) continue;

      final factorName = line.substring(0, colonIdx).trim();
      final valuesStr = line.substring(colonIdx + 1).trim();

      // Parse values (handle quoted strings for dropdowns)
      final values = <String>[];
      final parts = valuesStr.split(',');

      for (final part in parts) {
        var value = part.trim();
        // Remove quotes if present
        if (value.startsWith('"') && value.endsWith('"')) {
          value = value.substring(1, value.length - 1);
        }
        if (value.isNotEmpty) {
          values.add(value);
        }
      }

      if (factorName.isNotEmpty && values.isNotEmpty) {
        factors[factorName] = values;
      }
    }

    return factors;
  }

  /// Validate PICT constraint syntax line-by-line.
  ///
  /// Supports two formats:
  ///   Format A (dataset override): `key = value`
  ///   Format B (PICT constraint):  `IF [param] = "value" THEN [param] = "value";`
  ///
  /// Returns null if valid, or an error message string if invalid.
  String? validateConstraintsSyntax(String constraints) {
    final lines = constraints.split('\n');

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      final lineNum = i + 1;

      // Skip empty lines and comments
      if (line.isEmpty || line.startsWith('#')) continue;

      final hasIf = line.contains('IF');
      final hasThen = line.contains('THEN');

      // Format A: Dataset constraint  key = value  OR  key.slot = value
      if (!hasIf && !hasThen) {
        if (!RegExp(r'^[\w.]+\s*=\s*.+$').hasMatch(line)) {
          return 'Line $lineNum: Expected "key = value", "key.slot = value", or PICT "IF [...] = "..." THEN [...] = "...";"\n"$line"';
        }
        continue;
      }

      // Format B: PICT constraint  IF [...] ... THEN [...] ...;
      final thenIndex = line.indexOf('THEN');
      final ifPart = line.substring(0, thenIndex);
      final thenPart = line.substring(thenIndex);

      if (!RegExp(r'\[.+?\]').hasMatch(ifPart)) {
        return 'Line $lineNum: IF parameter must be in [brackets]\n"$line"';
      }
      if (!RegExp(r'\[.+?\]').hasMatch(thenPart)) {
        return 'Line $lineNum: THEN parameter must be in [brackets]\n"$line"';
      }
      if (!RegExp(r'".+?"').hasMatch(ifPart)) {
        return 'Line $lineNum: IF value must be in "quotes"\n"$line"';
      }
      if (!RegExp(r'".+?"').hasMatch(thenPart)) {
        return 'Line $lineNum: THEN value must be in "quotes"\n"$line"';
      }
      if (!line.endsWith(';')) {
        return 'Line $lineNum: Constraint must end with ;\n"$line"';
      }
    }

    return null;
  }

  /// Read factor names from .full.model.txt file
  ///
  /// Returns: List of factor names in order they appear in the model
  List<String> readFactorNamesFromModel(String modelFilePath) {
    final file = File(modelFilePath);
    if (!file.existsSync()) return [];

    final content = file.readAsStringSync();
    final factors = parsePictModel(content);
    return factors.keys.toList();
  }

  // ==========================================================================
  // Manifest-based PICT Model Generation
  // ==========================================================================

  /// Extract factors from UI manifest widgets
  ///
  /// Detects:
  /// - TextFormField/TextField -> Uses actual widget key as factor name
  /// - Radio groups -> Uses groupValueBinding or extracted group name
  /// - DropdownButtonFormField -> Uses actual widget key as factor name
  /// - Checkbox -> Uses actual widget key as factor name
  ///
  /// Returns: FactorExtractionResult containing factors and required checkboxes
  FactorExtractionResult extractFactorsFromManifest(List<Map<String, dynamic>> widgets) {
    final factors = <String, List<String>>{};
    final requiredCheckboxes = <String>{}; // Track which checkboxes are required

    // Track radio groups by groupValueBinding
    final radioGroups = <String, String>{}; // groupValueBinding -> factorName

    for (final w in widgets) {
      final widgetType = (w['widgetType'] ?? '').toString();
      final key = (w['key'] ?? '').toString();

      // Text inputs as factors: use actual widget key as factor name
      final isTextField = widgetType.startsWith('TextFormField') || widgetType.startsWith('TextField');
      if (isTextField && key.isNotEmpty) {
        // Use the actual widget key as factor name
        factors[key] = ['valid', 'invalid'];
      }

      // Individual Radio button - extract suffix and group by groupValueBinding
      if (widgetType.startsWith('Radio<') && key.isNotEmpty) {
        final meta = (w['meta'] as Map?)?.cast<String, dynamic>() ?? const {};
        final groupValue = meta['groupValueBinding']?.toString() ?? '';

        // Get or create factor name for this radio group
        String factorName;
        if (radioGroups.containsKey(groupValue)) {
          factorName = radioGroups[groupValue]!;
        } else {
          // Extract group name from groupValueBinding or use a descriptive name
          // Example: groupValue='age_radio_group' or use extracted description from first radio key
          factorName = groupValue.isNotEmpty ? groupValue : _extractRadioGroupName(key);
          radioGroups[groupValue] = factorName;
          factors[factorName] = <String>[];
        }

        // Extract suffix by removing prefix pattern: {page}_{sequence}_
        // Example: customer_05_age_10_20_radio -> age_10_20_radio
        final suffix = _extractRadioKeySuffix(key);
        if (suffix.isNotEmpty) {
          final list = factors[factorName]!..remove(suffix);
          list.add(suffix);
        }
        continue;
      }

      // Dropdown - use actual widget key as factor name
      if (widgetType.startsWith('DropdownButtonFormField') && key.isNotEmpty) {
        final meta = (w['meta'] as Map?)?.cast<String, dynamic>() ?? const {};
        final items = _extractOptionsFromMeta(meta['options']);
        if (items.isNotEmpty) {
          // Use actual widget key as factor name
          factors[key] = items;
        }
        continue;
      }

      // Checkbox - use actual widget key as factor name
      // Include all checkboxes in PICT model (both required and optional)
      // NOTE: Skip FormField<bool> as it's a wrapper widget, not an interactive element
      //       The actual Checkbox inside should be used as the factor instead
      if (widgetType == 'Checkbox' && key.isNotEmpty) {
        // Use actual widget key as factor name
        factors[key] = ['checked', 'unchecked'];
      }

      // Switch/SwitchListTile - same as Checkbox
      if ((widgetType == 'Switch' || widgetType == 'SwitchListTile') && key.isNotEmpty) {
        factors[key] = ['on', 'off'];
      }

      // Slider - extract min/mid/max values
      if (widgetType == 'Slider' && key.isNotEmpty) {
        final meta = (w['meta'] as Map?)?.cast<String, dynamic>() ?? const {};
        final min = (meta['min'] as num?)?.toDouble() ?? 0.0;
        final max = (meta['max'] as num?)?.toDouble() ?? 100.0;
        final mid = (min + max) / 2;

        factors[key] = [
          min.round().toString(),
          mid.round().toString(),
          max.round().toString(),
        ];
      }

      // DatePicker/TimePicker detection (check for pickerMetadata)
      final pickerMeta = (w['pickerMetadata'] as Map?)?.cast<String, dynamic>();
      if (pickerMeta != null && key.isNotEmpty) {
        final pickerType = (pickerMeta['type'] ?? '').toString();

        if (pickerType == 'DatePicker') {
          // Generate real dates based on constraints
          final dateValues = _generateDateValues(pickerMeta);
          factors[key] = dateValues;
        } else if (pickerType == 'TimePicker') {
          // Generate real times
          factors[key] = ['09:00', '14:30', '18:00', 'null'];
        }
      }

      // Detect required checkboxes from FormField<bool> validators
      // NOTE: FormField<bool> is NOT added as a factor (it's a wrapper widget)
      //       But we still need to detect if it has a "required" validator
      //       to mark the inner Checkbox as required
      if (widgetType.startsWith('FormField<bool>') && key.isNotEmpty) {
        final meta = (w['meta'] as Map?)?.cast<String, dynamic>() ?? const {};
        final rules = (meta['validatorRules'] as List?)?.cast<dynamic>() ?? const [];

        for (final rule in rules) {
          if (rule is Map) {
            final condition = rule['condition']?.toString() ?? '';
            // Check if condition requires value to be true
            // Pattern: "value == null || !value" means checkbox must be checked
            final normalized = condition.toLowerCase().replaceAll(' ', '');
            if (normalized.contains('!value') ||
                normalized.contains('value==false') ||
                (normalized.contains('value==null') && normalized.contains('||!value'))) {
              // Find the associated Checkbox key by replacing _formfield with _checkbox
              // Example: customer_06_agree_terms_formfield -> customer_06_agree_terms_checkbox
              final checkboxKey = key.replaceAll('_formfield', '_checkbox');
              requiredCheckboxes.add(checkboxKey);
              break;
            }
          }
        }
        continue; // Skip adding FormField<bool> as a factor
      }
    }

    return FactorExtractionResult(
      factors: factors,
      requiredCheckboxes: requiredCheckboxes,
    );
  }

  /// Extract radio group name from radio key
  /// Example: customer_05_age_10_20_radio -> age_radio_group
  String _extractRadioGroupName(String radioKey) {
    // Pattern: {page_prefix}_{sequence}_{description}_{value}_radio
    // Extract description part
    final parts = radioKey.split('_');
    if (parts.length > 2) {
      // Find where the description starts (after sequence number)
      int descStartIdx = 2;
      // Skip sequence number if present
      if (parts.length > 1 && int.tryParse(parts[1]) != null) {
        descStartIdx = 2;
      }

      // Find where value starts (usually before last _radio or second-to-last part)
      int descEndIdx = parts.length - 2;
      if (parts.last == 'radio' && parts.length > 3) {
        descEndIdx = parts.length - 2;
      }

      if (descStartIdx < descEndIdx) {
        // Extract description (e.g., "age" from customer_05_age_10_20_radio)
        final description = parts[descStartIdx];
        return '${description}_radio_group';
      }
    }
    return 'radio_group'; // fallback
  }

  String _factorNameForRadioGroupKey(String key) {
    final match = RegExp(r'_radio(\d+)_group').firstMatch(key);
    if (match != null) return 'Radio${match.group(1)}';
    return 'Radio1'; // fallback
  }

  /// Extract Radio key suffix by removing prefix pattern
  /// Example: customer_05_age_10_20_radio -> age_10_20_radio
  String _extractRadioKeySuffix(String radioKey) {
    // Pattern: {page_prefix}_{sequence}_{description}_{value}_radio
    // Split by underscore and skip first 2 parts (page prefix and sequence)
    final parts = radioKey.split('_');
    if (parts.length > 2) {
      // Join remaining parts (description + value + radio)
      return parts.skip(2).join('_');
    }
    return radioKey; // fallback to full key if pattern doesn't match
  }

  String _extractRadioOptionLabel(String radioKey) {
    // e.g., buttons_approve_radio -> approve
    final match = RegExp(r'^[^_]+_(.+?)_radio$').firstMatch(radioKey);
    if (match != null) return match.group(1)!.toLowerCase();
    return radioKey.toLowerCase();
  }

  /// Generate date values based on DatePicker metadata constraints
  List<String> _generateDateValues(Map<String, dynamic> pickerMeta) {
    final values = <String>[];

    // Parse firstDate and lastDate from metadata
    final firstDateStr = (pickerMeta['firstDate'] ?? '').toString();
    final lastDateStr = (pickerMeta['lastDate'] ?? '').toString();

    DateTime? firstDate;
    DateTime? lastDate;
    final now = DateTime.now();

    // Parse firstDate
    if (firstDateStr.contains('DateTime(1900)')) {
      firstDate = DateTime(1900);
    } else if (firstDateStr.contains('DateTime.now()')) {
      firstDate = now;
    } else {
      // Try to extract year from DateTime(year)
      final yearMatch = RegExp(r'DateTime\((\d{4})\)').firstMatch(firstDateStr);
      if (yearMatch != null) {
        firstDate = DateTime(int.parse(yearMatch.group(1)!));
      }
    }

    // Parse lastDate
    if (lastDateStr.contains('DateTime.now()')) {
      if (lastDateStr.contains('add') && lastDateStr.contains('365')) {
        lastDate = now.add(const Duration(days: 365));
      } else {
        lastDate = now;
      }
    } else {
      final yearMatch = RegExp(r'DateTime\((\d{4})\)').firstMatch(lastDateStr);
      if (yearMatch != null) {
        lastDate = DateTime(int.parse(yearMatch.group(1)!));
      }
    }

    // Generate test dates within constraints
    firstDate ??= DateTime(2000);
    lastDate ??= DateTime(2030);

    // null (cancel) - always include
    values.add('null');

    // past_date - close to firstDate
    final pastDate = DateTime(
      firstDate.year + 1,
      firstDate.month,
      15.clamp(1, 28),
    );
    if (pastDate.isAfter(firstDate) && pastDate.isBefore(lastDate)) {
      values.add('${pastDate.day.toString().padLeft(2, '0')}/${pastDate.month.toString().padLeft(2, '0')}/${pastDate.year}');
    }

    // today - if within range
    if (now.isAfter(firstDate) && now.isBefore(lastDate)) {
      values.add('${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}');
    }

    // future_date - close to lastDate
    final futureDate = DateTime(
      lastDate.year - 1,
      lastDate.month,
      15.clamp(1, 28),
    );
    if (futureDate.isAfter(firstDate) && futureDate.isBefore(lastDate) && futureDate.isAfter(now)) {
      values.add('${futureDate.day.toString().padLeft(2, '0')}/${futureDate.month.toString().padLeft(2, '0')}/${futureDate.year}');
    }

    // Ensure we have at least 2 non-null values
    if (values.length < 3) {
      // Add a middle date
      final middleDate = DateTime(
        (firstDate.year + lastDate.year) ~/ 2,
        6,
        15,
      );
      values.add('${middleDate.day.toString().padLeft(2, '0')}/${middleDate.month.toString().padLeft(2, '0')}/${middleDate.year}');
    }

    return values;
  }

  List<String> _extractOptionsFromMeta(dynamic raw) {
    final out = <String>[];
    if (raw is List) {
      for (final entry in raw) {
        if (entry is Map) {
          // Use value field for PICT compatibility (ASCII only)
          final value = entry['value']?.toString();
          final text = entry['text']?.toString();
          final label = entry['label']?.toString();
          final chosen = (value != null && value.isNotEmpty) ? value
                       : (text != null && text.isNotEmpty) ? text
                       : label;
          if (chosen != null && chosen.isNotEmpty) {
            // Replace spaces with underscores for PICT compatibility
            final cleaned = chosen.replaceAll(' ', '_');
            out.add(cleaned);
          }
        } else if (entry != null) {
          final s = entry.toString();
          if (s.isNotEmpty) {
            final cleaned = s.replaceAll(' ', '_');
            out.add(cleaned);
          }
        }
      }
    }
    return out;
  }

  // ==========================================================================
  // PICT Model File Management
  // ==========================================================================

  /// Write PICT model files and execute PICT to generate result files
  ///
  /// Generates:
  /// - model_pairwise/<page>.model.txt / <page>.valid.model.txt (input models)
  /// - model_pairwise/<page>.result.txt / <page>.valid.result.txt (PICT results)
  Future<void> writePictModelFiles({
    required Map<String, List<String>> factors,
    required String pageBaseName,
    Set<String> requiredCheckboxes = const {},
    String? constraints,
  }) async {
    if (factors.isEmpty) return;

    stderr.writeln('[DEBUG] writePictModelFiles - constraints: '
        '${constraints == null ? "NULL" : "present (${constraints.length} chars)"}');

    final modelContent = generatePictModel(factors, constraints: constraints);
    final validModelContent = generateValidOnlyPictModel(
      factors,
      requiredCheckboxes: requiredCheckboxes,
      constraints: constraints,
    );

    // Create output/model_pairwise directory
    final outputDir = Directory('output/model_pairwise');
    if (!outputDir.existsSync()) {
      outputDir.createSync(recursive: true);
    }

    // Write page-specific model files only (no root-level files)
    final outPageModel = 'output/model_pairwise/$pageBaseName.full.model.txt';
    final outPageValidModel = 'output/model_pairwise/$pageBaseName.valid.model.txt';
    File(outPageModel).writeAsStringSync(modelContent);
    File(outPageValidModel).writeAsStringSync(validModelContent);

    // Execute PICT on page-specific models to generate result files
    await _executePictToFile(
      outPageModel,
      'output/model_pairwise/$pageBaseName.full.result.txt',
    );
    await _executePictToFile(
      outPageValidModel,
      'output/model_pairwise/$pageBaseName.valid.result.txt',
    );
  }

  Future<void> _executePictToFile(String modelPath, String outputPath) async {
    try {
      final result = await Process.run(pictBin, [modelPath]);
      if (result.exitCode == 0) {
        final output = (result.stdout is String)
            ? (result.stdout as String)
            : String.fromCharCodes((result.stdout as List<int>));
        File(outputPath).writeAsStringSync(output);
      } else {
        stderr.writeln('! PICT failed for $modelPath: ${result.stderr}');
      }
    } catch (e) {
      stderr.writeln('! PICT execution error for $modelPath: $e');
    }
  }

  // ==========================================================================
  // Internal Pairwise Algorithm (Fallback)
  // ==========================================================================

  /// Generate pairwise combinations using internal algorithm
  /// Used as fallback when PICT binary is unavailable
  ///
  /// Algorithm: Greedy set cover to find minimal test set covering all pairs
  List<Map<String, String>> generatePairwiseInternal(Map<String, List<String>> factors) {
    if (factors.isEmpty) return const [];

    final names = factors.keys.toList();
    if (names.length <= 1) {
      if (names.isEmpty) return const [];
      return factors[names[0]]!.map((v) => {names[0]: v}).toList();
    }

    // Generate all possible pairs that need to be covered
    final requiredPairs = <String>{};
    for (int i = 0; i < names.length; i++) {
      for (int j = i + 1; j < names.length; j++) {
        final factor1 = names[i];
        final factor2 = names[j];
        for (final val1 in factors[factor1]!) {
          for (final val2 in factors[factor2]!) {
            requiredPairs.add('$factor1=$val1|$factor2=$val2');
          }
        }
      }
    }

    // Generate all possible test cases
    final allCases = <Map<String, String>>[];
    void generateAllCombinations(int factorIndex, Map<String, String> current) {
      if (factorIndex == names.length) {
        allCases.add(Map.from(current));
        return;
      }

      final factorName = names[factorIndex];
      for (final value in factors[factorName]!) {
        current[factorName] = value;
        generateAllCombinations(factorIndex + 1, current);
      }
    }
    generateAllCombinations(0, {});

    // Greedy algorithm to find minimal set covering all pairs
    final selectedCases = <Map<String, String>>[];
    final coveredPairs = <String>{};

    while (coveredPairs.length < requiredPairs.length && allCases.isNotEmpty) {
      Map<String, String>? bestCase;
      int bestScore = -1;

      // Find the case that covers the most uncovered pairs
      for (final testCase in allCases) {
        int score = 0;

        // Calculate how many new pairs this case would cover
        for (int i = 0; i < names.length; i++) {
          for (int j = i + 1; j < names.length; j++) {
            final factor1 = names[i];
            final factor2 = names[j];
            final pairKey = '$factor1=${testCase[factor1]}|$factor2=${testCase[factor2]}';
            if (!coveredPairs.contains(pairKey)) {
              score++;
            }
          }
        }

        if (score > bestScore) {
          bestScore = score;
          bestCase = testCase;
        }
      }

      if (bestCase == null) break;

      // Add the best case and mark its pairs as covered
      selectedCases.add(bestCase);
      allCases.remove(bestCase);

      for (int i = 0; i < names.length; i++) {
        for (int j = i + 1; j < names.length; j++) {
          final factor1 = names[i];
          final factor2 = names[j];
          final pairKey = '$factor1=${bestCase[factor1]}|$factor2=${bestCase[factor2]}';
          coveredPairs.add(pairKey);
        }
      }
    }

    return selectedCases;
  }

  // ==========================================================================
  // High-level API
  // ==========================================================================

  /// Generate pairwise test combinations from UI manifest
  ///
  /// Automatically:
  /// 1. Extracts factors from manifest widgets
  /// 2. Generates PICT model files
  /// 3. Executes PICT (or uses internal algorithm as fallback)
  /// 4. Returns test combinations
  Future<PairwiseResult> generatePairwiseFromManifest({
    required String manifestPath,
    required String uiFilePath,
    bool usePict = true,
    String? constraints,
  }) async {
    // Read manifest
    final manifestFile = File(manifestPath);
    if (!manifestFile.existsSync()) {
      throw Exception('Manifest not found: $manifestPath');
    }

    final manifestJson = jsonDecode(manifestFile.readAsStringSync()) as Map<String, dynamic>;
    final widgets = (manifestJson['widgets'] as List? ?? const []).cast<Map<String, dynamic>>();

    // Extract factors and required checkboxes
    final extractionResult = extractFactorsFromManifest(widgets);
    final factors = extractionResult.factors;
    final requiredCheckboxes = extractionResult.requiredCheckboxes;

    if (factors.isEmpty) {
      return PairwiseResult(
        combinations: [],
        validCombinations: [],
        factors: {},
        method: 'none',
      );
    }

    // Generate PICT model files
    final pageBase = utils.basenameWithoutExtension(uiFilePath);
    await writePictModelFiles(
      factors: factors,
      pageBaseName: pageBase,
      requiredCheckboxes: requiredCheckboxes,
      constraints: constraints,
    );

    // Generate combinations
    List<Map<String, String>> combinations;
    List<Map<String, String>> validCombinations;
    String method;

    if (usePict) {
      try {
        combinations = await executePict(factors, constraints: constraints);

        // Generate valid-only combinations
        final validFactors = <String, List<String>>{};
        for (final entry in factors.entries) {
          if (entry.key.startsWith('TEXT')) {
            validFactors[entry.key] = ['valid'];
          } else {
            validFactors[entry.key] = entry.value;
          }
        }
        validCombinations = await executePict(validFactors, constraints: constraints);
        method = 'pict';
      } catch (e) {
        stderr.writeln('! PICT failed: $e. Using internal algorithm.');
        combinations = generatePairwiseInternal(factors);
        validCombinations = [];
        method = 'internal';
      }
    } else {
      combinations = generatePairwiseInternal(factors);
      validCombinations = [];
      method = 'internal';
    }

    return PairwiseResult(
      combinations: combinations,
      validCombinations: validCombinations,
      factors: factors,
      method: method,
    );
  }
}

// Removed: _basenameWithoutExtension - now using utils.basenameWithoutExtension

/// Result of factor extraction from manifest
class FactorExtractionResult {
  final Map<String, List<String>> factors;
  final Set<String> requiredCheckboxes;

  FactorExtractionResult({
    required this.factors,
    required this.requiredCheckboxes,
  });
}

/// Result of pairwise generation
class PairwiseResult {
  final List<Map<String, String>> combinations;
  final List<Map<String, String>> validCombinations;
  final Map<String, List<String>> factors;
  final String method; // 'pict' or 'internal'

  PairwiseResult({
    required this.combinations,
    required this.validCombinations,
    required this.factors,
    required this.method,
  });
}
